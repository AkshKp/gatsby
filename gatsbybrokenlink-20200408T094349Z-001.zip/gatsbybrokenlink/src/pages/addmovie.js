import React from 'react'
import { graphql , useStaticQuery ,Link } from 'gatsby'
import Layout from '../components/layout'


const MoviesList =()=>{

    
  const data= useStaticQuery(graphql`
  query{
  swapi
  {
    allFilms {
      id 
      title
      director
      producers
      releaseDate
    }
  }
  }
  `)

    return (
    
   
    
   <Layout>
     <div>
     <table>
       <thead>
         <tr>
         <th>Title</th>
           <th>Director</th>
           <th>Producers</th>
           <th>Release Date</th>
           
         </tr>
       </thead>
       <tbody>
       {data.swapi.allFilms.map(film=> (
          <tr key={film.id}>
            <Link to={`addmovie/${film.title}`}><td>{film.title}</td></Link>
           <td>{film.director}</td>
           <td>{film.producers}</td>
           <td>{film.releaseDate}</td>
           </tr>
         ))}
      
       </tbody>
     </table>
     </div>
     </Layout>
     
    )
  }






export default MoviesList



















/* import React  from "react"
import Layout from "../components/layout"
import MoviesList from '../components/movieslist'

const AddMovies =()=>{

  return(
    <div>
      <Layout>
        <h1>Movies List</h1>
        <MoviesList/>
      </Layout>
    </div>
  )

}

export default AddMovies; */