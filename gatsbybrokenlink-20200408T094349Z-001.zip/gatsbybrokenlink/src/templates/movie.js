
import React ,{Component} from 'react'
import Layout from '../components/layout'
//import {getCookie,setCookie,logCookie} from '../cookie'
//import Cookies from 'universal-cookie'
//const cookies = new Cookies()
class Movie extends Component{

/* 
  componentDidMount(){
    setCookie('username','manoj',1)
    console.log("Browser Cookie  "+getCookie('username'))
  }
  state={
    name: getCookie('username')
  } */

render()
{
  const {pageContext } = this.props

  return(
    <Layout>
    <div>
   {/* {console.log("state cookie"+this.state.name)}  */}

    {/* {this.state.name && <h1>Hello {this.state.name}!</h1>} */}
    <table>
      <thead>
        <tr>
        <th>Title</th>
          <th>Director</th>
          <th>Producers</th>
          <th>Release Date</th>
          
        </tr>
      </thead>
      <tbody>
      
         <tr key={pageContext.id}>
          <td>{pageContext.title}</td>
          <td>{pageContext.director}</td>
          <td>{pageContext.producers}</td>
          <td>{pageContext.releaseDate}</td>
          </tr>
        
     
      </tbody>
    </table>
    {/* <button onClick={logCookie}>Get cookie details</button> */}
    </div>
    </Layout>
  )
}


} 

export default Movie;


















