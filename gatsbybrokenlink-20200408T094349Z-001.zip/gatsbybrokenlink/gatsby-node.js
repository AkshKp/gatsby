
const path = require('path')
exports.createPages = async ({ actions, graphql }) => {
  const movieComponent = path.resolve('./src/templates/movie.js')

  const {data} = await graphql(`
  query {
    swapi {
      allFilms {
        id
        title
        director
        producers
        releaseDate
      }
    }
  }
  `)
   

   data.swapi.allFilms.forEach(film => {
    console.log("Film Title"+ film.title)

    actions.createPage({
      path: `/addmovie/${film.title}`,
      component: movieComponent,
      context: {
        title: film.title,
        director:film.director,
        producers:film.producers,
        releaseDate:film.releaseDate,
      },
    })
    console.log("Path Name"+path)

  }) 
  

    
}

