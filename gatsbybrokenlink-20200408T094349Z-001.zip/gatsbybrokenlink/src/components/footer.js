import React from "react"

const Footer = () => {
    return (
    <footer>
        <p>Created by Prathyusha @2020</p>
    </footer>
    ) 
}
 export default Footer