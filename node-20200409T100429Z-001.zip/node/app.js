const express = require('express');
const app = express();
var cors = require('cors')
var mongoose = require('mongoose');
const {HtmlUrlChecker} = require('broken-link-checker');
var MongoClient = require('mongodb').MongoClient;
const bodyParser = require("body-parser");

const port = process.env.PORT || 5001;
app.use(cors())

mongoose.createConnection('mongodb://localhost:27017',{ useNewUrlParser :"true"});
mongoose.createConnection(function(err, db) {
  if (err) throw err;
  var dbo = db.db("brokenlinks");


 app.get('/demo',(req,res)=>{

  var linksData = [];
 
  var htmlUrlChecker = new HtmlUrlChecker({}, {
    html: function(tree, robots, response, pageUrl, customData){},
    junk: function(result, customData){},
    link: function(result, customData){
      linksData.push(result);  
      
     
    },
    page: function(error, pageUrl, customData){},
    end: function(){
      dbo.collection("brokenlinklist").insertMany(linksData, function(err, response) {
        if (err) throw err;
        console.log(JSON.stringify(response));
        res.send(response)
        mongo.close();
      });
      
    },
});
htmlUrlChecker.enqueue('http://addmovie.000webhostapp.com');

}) 
 

app.get('/', (req, res) => {
   res.send({ express: 'YOUR EXPRESS BACKEND IS CONNECTED TO REACT' });
});


});


app.listen(port, () => console.log(`Listening on port ${port}`));
