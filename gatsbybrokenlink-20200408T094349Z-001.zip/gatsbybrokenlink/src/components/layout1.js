import React, { Component } from 'react'
import Menu from '../components/menu'
import Header from '../components/header'
class Layout extends Component{



createMenu(){

      return <Menu/>

}
createBody(){

}
createHeader(){
    
    return <Header/>

}

render(){

    return(
        <div>
            {this.createHeader()}
            {this.createBody()}
            {this.createMenu()}
        </div>
    )
}

}


export default Layout;