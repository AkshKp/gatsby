import React from 'react'
import Layout from '../components/layout'
//import Cookies from 'universal-cookie'
//import  {getCookie} from '../cookie'

//const cookies = new Cookies()
//console.log('Cookie1 '+getCookie('fname'))
//console.log('Cookie2 '+getCookie('name'))

const ContactPage =() =>{
  return(
<Layout>
<h1>Contact Page </h1>
    <p>
      Welcome to ContactPage
    </p>
</Layout>
  )
}


export default ContactPage