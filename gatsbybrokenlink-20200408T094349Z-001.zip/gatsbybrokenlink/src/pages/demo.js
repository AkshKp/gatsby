import React, { Component } from "react"
import Layout from "../components/layout"

//
class DemoPage extends Component {


  constructor(props){
    super(props)
    this.state = {
      data: []
    };
  }
 

  componentDidMount() {
    // Call our fetch function below once the component mounts
  this.callBackendAPI()
    .then(res => {
      const data = res
      this.setState({data})
    }
    
      )
    .catch(err => console.log(err));
     
  
}
  // Fetches our GET route from the Express server. (Note the route we are fetching matches the GET route from server.js
callBackendAPI = async () => {
  const response = await fetch('http://localhost:5001/demo');
  const body = await response.json(); 

  if (response.status !== 200) {
    throw Error(body.message) 
  }
  return body;
};



  render(){
    return(
        <Layout>
        <div>
            <h1>Demo  </h1>
            {console.log(this.state.data)}
             <table>
       <thead>
         <tr>
        
         <th>Page</th>
          
         <th>Page Status</th> 
         </tr>
       </thead>
       <tbody>
       { this.state.data.map(res=>{
         return(
          <tr>
          <td>{res.ops.url.resolved}</td>
         <td>{res.ops.http.response.statusMessage}</td>

          
        </tr>
         )
       })
        }
        
       
      
       </tbody>
     </table> 
 

 






        </div>
        </Layout>
    )
  }
}
/* 
request('http://localhost:8000/demo', function (error, response, body) {
  console.error('error:', error); 
  console.log('statusCode:', response && response.statusCode); 
  console.log('body:', body); // Print the HTML for the Google homepage.
}); */

export default DemoPage