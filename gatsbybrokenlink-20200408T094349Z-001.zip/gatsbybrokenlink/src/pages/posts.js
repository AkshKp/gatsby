import React, { Component } from 'react';
import Layout from '../components/layout'

const axios  = require('axios')

class Post extends Component{

state={
    posts:[]
}

componentDidMount() {
    axios.get('https://jsonplaceholder.typicode.com/posts')
      .then(res => {
        const posts = res.data;
        this.setState({ posts });
      })


      axios.get('https://jsonplaceholder.typicode.com/posts', 
      
      { headers: {Cookie: "cookie1=value; cookie2=value; cookie3=value;",withCredentials: true}},
      
      )

     
}

render(){


console.log(this.state.posts)


return(
    <Layout>
            <h1>Post</h1>
            <ul>
              {
               this.state.posts.map(post => <li>{post.title}</li>)
               }
             </ul>
    </Layout>
)

}




}

export default Post;