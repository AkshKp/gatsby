import React, { Component } from "react"
import Layout from '../components/layout'
//import {getCookie,setCookie} from '../cookie'

//import Cookies from 'universal-cookie'

//const cookies = new Cookies()


class IndexPage extends Component{

componentDidMount(){
  // setCookie('username','manoj',1)
  // console.log(getCookie('username'))
}

/*   
componentDidMount(){


  var d = new Date();
  d.setTime(d.getTime() + (1*1000));
  var expires = "expires="+ d.toUTCString();  
  cookies.set('name' , 'Lakshman' ,{path:'/'});
  cookies.set('firstname' , 'saikumar' ,{path:'/'},{expires:expires});
  cookies.set('fname' , 'saikumar' ,{path:'/contact'},{expires:expires});
  cookies.set('mname' , 'saikumar' ,{path:'/addmovie/'},{expires:expires});
  
  console.log(cookies.get('name'))
  
} */
  render(){
    
    // setCookie('username','manoj',100)

  return(
    <Layout>
   <h1>Index Page</h1>
  
    </Layout>
  )
}
}
export default IndexPage
